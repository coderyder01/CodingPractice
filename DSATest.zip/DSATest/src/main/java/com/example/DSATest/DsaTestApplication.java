package com.example.DSATest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsaTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsaTestApplication.class, args);
	}

}
