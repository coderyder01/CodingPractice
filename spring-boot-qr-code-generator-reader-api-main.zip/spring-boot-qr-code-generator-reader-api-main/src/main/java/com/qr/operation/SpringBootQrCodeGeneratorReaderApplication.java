package com.qr.operation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootQrCodeGeneratorReaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootQrCodeGeneratorReaderApplication.class, args);
	}

}
