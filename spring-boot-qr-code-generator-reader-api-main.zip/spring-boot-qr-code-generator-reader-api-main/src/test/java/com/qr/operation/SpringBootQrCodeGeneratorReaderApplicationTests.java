package com.qr.operation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootQrCodeGeneratorReaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
