package com.qr.operation.utils;

public class Constants {
    public static final String SLASH = "/";
}
